#!/usr/bin/env bash
set -e
TARGET="/root/.openclaw/.openclaw/workspace"
if [ "$1" = "--target" ] && [ -n "$2" ]; then
  TARGET="$2"
fi
if [ ! -d "$TARGET" ]; then
  echo "Target does not exist: $TARGET" >&2
  exit 1
fi
BACKUP_TS="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_DIR="$TARGET/backup-personality-$BACKUP_TS"
mkdir -p "$BACKUP_DIR"
# Copy existing files to backup
for f in SOUL.md IDENTITY.md AGENTS.md USER.md TOOLS.md HEARTBEAT.md MEMORY.md BOOTSTRAP.md; do
  if [ -f "$TARGET/$f" ]; then
    cp -a "$TARGET/$f" "$BACKUP_DIR/"
  fi
done
# Copy new files in
cp -a files/* "$TARGET/"
# Set safe perms for MEMORY.md if present
if [ -f "$TARGET/MEMORY.md" ]; then
  chmod 600 "$TARGET/MEMORY.md"
fi
echo "Restored files to $TARGET (previous files backed up to $BACKUP_DIR)"
