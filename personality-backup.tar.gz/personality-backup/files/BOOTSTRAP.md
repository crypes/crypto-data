[MISSING] Expected at: /root/.openclaw/.openclaw/workspace/BOOTSTRAP.md
