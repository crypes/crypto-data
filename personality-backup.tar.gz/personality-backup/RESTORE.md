Restore instructions

1. Clone or extract this repo on the target host.
2. Review files in files/ for any sensitive data before restoring.
3. To restore to the default workspace path, run:

   sudo bash ./restore_personality.sh --target /root/.openclaw/.openclaw/workspace

   The script will back up any existing files into a timestamped directory before copying.

4. To decrypt MEMORY.md.enc (if present):

   OpenSSL is required. Run:

   openssl enc -d -aes-256-cbc -pbkdf2 -iter 100000 -in files/MEMORY.md.enc -out MEMORY.md -pass pass:YOUR_PASSPHRASE

   Replace YOUR_PASSPHRASE with the passphrase you hold separately (not included in this repo).

Warnings:
- Do not place unencrypted secrets into this repo.
- The gateway is managed externally; do NOT run openclaw gateway start/stop unless you manage the gateway.
