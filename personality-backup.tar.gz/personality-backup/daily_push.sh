#!/usr/bin/env bash
set -e
# This script updates the personality backup from the live workspace and pushes to origin/personality-backup.
BASEDIR=/root/.openclaw/.openclaw/workspace
REPO_DIR=$(dirname "$0")
FILES_DIR="$REPO_DIR/files"
# Copy latest files
for f in SOUL.md IDENTITY.md AGENTS.md USER.md TOOLS.md HEARTBEAT.md BOOTSTRAP.md; do
  if [ -f "$BASEDIR/$f" ]; then
    cp -a "$BASEDIR/$f" "$FILES_DIR/"
  fi
done
# If a key file with the passphrase exists at /root/.personality_key, use it to encrypt MEMORY.md
if [ -f /root/.personality_key ]; then
  if [ -f "$BASEDIR/MEMORY.md" ]; then
    openssl enc -aes-256-cbc -salt -pbkdf2 -iter 100000 -pass file:/root/.personality_key -in "$BASEDIR/MEMORY.md" -out "$FILES_DIR/MEMORY.md.enc"
    rm -f "$FILES_DIR/MEMORY.md"
  fi
fi
cd "$REPO_DIR"
if git add -A && git commit -m "Daily backup: $(date -u +%Y-%m-%dT%H:%M:%SZ)"; then
  git push origin personality-backup || true
fi
