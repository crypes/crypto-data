Personality backup for Pogo (AI companion)

This repository contains the core files needed to restore the assistant's "personality": SOUL.md, IDENTITY.md, AGENTS.md, USER.md, TOOLS.md, HEARTBEAT.md, and an encrypted MEMORY.md (if present).

Security notes:
- MEMORY.md may contain sensitive data. An encrypted copy (MEMORY.md.enc) is included; the passphrase is not stored here.
- Do NOT share this repository without reviewing MEMORY.md contents and verifying the encryption key is kept secret.

Restore instructions are in RESTORE.md. Do not run openclaw gateway start/stop commands on the target host (the gateway is managed externally).
